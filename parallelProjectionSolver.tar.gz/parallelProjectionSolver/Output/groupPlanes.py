import os, time, sys
from os import system, remove, path

def main():
#######################################
# Option to create a case             #
#######################################
#######################################
    if(len(sys.argv)<4):
        print 'Please use option -h to see all available options'
        return

    if(len(sys.argv)==4):
        nameStr = '%s' %sys.argv[2]
        nProcs = '%s' %sys.argv[3]
        print sys.argv[1]
        print 'nameStr %s' %(nameStr)
        print 'nProcs %s' %(nProcs)
        bfn = 'grouped_%s.tec' %(nameStr) #baselineFileName
        rf = '%s_'%(nameStr) #readlineFile

#        myRange = range(0, int(MPIRanks))
        removeMainFile = 'rm %s' %(bfn)
        system(removeMainFile)

        myRange = range(0, int(nProcs));
        for i in myRange:
            print i
            appendCommand = 'cat %s%s.tec >> %s' %(rf,i, bfn)
            system(appendCommand)
#            print 'appending file %s%s.tec to %s' %(rf,i,bfn)

        if(sys.argv[1]=='keep'):
            print 'Partitioned files are kept since KEEP option was used'
        elif(sys.argv[1]=='remove'):
            print 'Partitioned files are removed since REMOVE option was used'
        else:
            print 'Unknown argument used, partitioned files are kept for safety'
        
    elif(sys.argv[1]=='-h'):
        print 'help option is invoked.'
        print 'LiberLocus multiscale multiphysics solver version 1.0.'
        print 'To post-process a case use 8000 32, the planeID and total number of MPI ranks'
if __name__ == "__main__":
    main()
