#ifndef __OPS_HPP__
#define __OPS_HPP__

#include <assert.h>
#include "nvector.hpp"

//
// Originally created by Makram Kamaleddine on 1/21/16. Added by Saurabh Sawant on 09/07/18.
// (for his QR_DECOMPOSITION code. I am using his construct_from_column_vectors function.)
// I have added vecMatMul and matVecMul functions. 

/**
 * Given a set of vectors that constitute the columns of a
 * matrix, construct the columns of the matrix.
 */
template<typename T>
matrix<T> construct_from_column_vectors(const container<nvector<T>>& basis)
{
#ifdef DEBUG
    // check if all the vectors are the same size
    auto size = basis.front().size();
    for (auto i = basis.begin(); i != basis.end(); ++i)
    {
        assert(size == i->size());
    }
#endif
    using size_type = typename matrix<T>::size_type;

    matrix<T> result(basis.front().size(), basis.size());

    for (size_type j = 0; j < basis.size(); ++j) {
        for (size_type i = 0; i < basis[j].size(); ++i) {
            result(i, j) = (basis[j])[i];
        }
    }

    return result;
}

template<typename T>
matrix<T> construct_from_row_vectors(const container<nvector<T>>& basis)
{
#ifdef DEBUG
    // check if all the vectors are the same size
    auto size = basis.front().size();
    for (auto i = basis.begin(); i != basis.end(); ++i)
    {
        assert(size == i->size());
    }
#endif
    using size_type = typename matrix<T>::size_type;

    matrix<T> result(basis.size(), basis.front().size());

    for (size_type i = 0; i < basis.size(); ++i) {
        for (size_type j = 0; j < basis[i].size(); ++j) {
            result(j, i) = (basis[i])[j];
        }
    }

    return result;
}


template<typename T>
dim<T> vecMatMul(const dim<T> arr, const matrix<T>& basis)
{
    using size_type = typename matrix<T>::size_type;
	dim<T> result;
    for (size_type j = 0; j < basis.colCount(); ++j)
    {   
        for (size_type i = 0; i < basis.rowCount(); ++i)
        {   
			result.x[j] += arr.x[i]*basis(i,j);
        }
    }

    return result;
}


template<typename T>
dim<T> matVecMul(const matrix<T>& basis, const dim<T> arr)
{
    using size_type = typename matrix<T>::size_type;
	dim<T> result;
	for (size_type i = 0; i < basis.rowCount(); ++i)
    {   
    	for (size_type j = 0; j < basis.colCount(); ++j)
        {   
			result.x[i] += basis(i,j)*arr.x[j];
        }
    }

    return result;
}

#endif 
