#include <fstream>
#include <iostream>
#include "io.hpp"
#include "rotationMatrix.hpp"
#include "plane.hpp"
#include "geometry.hpp"
#include <mpi.h>
#define Zeta_Cells 64 /*number of columns of intersected plane*/
#define Eta_Cells 64 /*rows of intersected plane*/
#define Zeta_Length 600.0 /*Note: choose the unit*/
#define Eta_Length 600.0 


int main(int argc, char *argv[]) {
	using std::cout;
	using Type = double;
	using size_type = unsigned long int;
	int MPI_PROC_TOTAL_NUM, MPI_PROC_ID;
	int ierr = MPI_Init(&argc, &argv);
	ierr = MPI_Comm_size(MPI_COMM_WORLD, &MPI_PROC_TOTAL_NUM);
	ierr = MPI_Comm_rank(MPI_COMM_WORLD, &MPI_PROC_ID);
	int MPI_PROC_PER_DIR = sqrt(MPI_PROC_TOTAL_NUM); /*choose total procs accordingly*/
	cout << "Processor " << MPI_PROC_ID << " is active.\n";
	if(MPI_PROC_ID == 0){
		cout << "Processor per direction " << MPI_PROC_PER_DIR << " is active.\n";
	}	
    pout.open((ProcessorPrintOutPath(MPI_PROC_ID)).c_str());
	
	size_type Zeta_CellsPerProc = Zeta_Cells/(Type)MPI_PROC_PER_DIR; /*choose cells accordingly*/
	size_type Eta_CellsPerProc = Eta_Cells/(Type)MPI_PROC_PER_DIR; 
	Type Zeta_LengthPerProc = (Type)Eta_Length/(Type)MPI_PROC_PER_DIR;
	Type Eta_LengthPerProc = (Type)Eta_Length/(Type)MPI_PROC_PER_DIR;

	if(MPI_PROC_ID == 0){
		pout << "Zeta and Eta lengths per proc: " << Zeta_LengthPerProc << std::setw(10) << Eta_LengthPerProc << "\n";
	}

	int sign[3] = {1,-1,-1}; /*zeta runs from -Y to Y and eta from -Z to Z. 
								For a normal in +X direction, sign is positive.*/
	plane<quadCell<Type>, Type> grid(MPI_PROC_ID,MPI_PROC_PER_DIR, Zeta_CellsPerProc, Eta_CellsPerProc, Zeta_LengthPerProc, Eta_LengthPerProc, 'X', sign);  /*vector of nvector*/
	grid.printPlaneInTecplot(MPI_PROC_ID, "Base");
    Type Theta[3] = {45,45,0}; /*should always have 3 angles defined */
	rotationMatrix<double> RotM(3,Theta[0], Theta[1], Theta[2]);
	cout << "RotM.Rx: " << RotM.Rx << "\n";
	cout << "RotM.Ry: " << RotM.Ry << "\n";
	cout << "RotM.Rz: " << RotM.Rz << "\n";
	
	std::array<char,2> rot_op = {'X','Y'}; /*This can take as many operations*/
	grid.rotatePlane(RotM, rot_op);
	
//	RotM.updateTheta(-45,-45,0);
//	grid.rotatePlane(RotM, std::array<char,2>{'Y', 'X'});
//	grid.printPlaneInTecplot(MPI_PROC_ID, "Rotxy");
	
	geometry<triPanel<Type>,Type> microStruct("avcoat_define");
	microStruct.centerAtOrigin();
	size_type projCellCounter =	grid.tagCutAndInnerCells(microStruct);
	size_type totalCells=0;
    MPI_Reduce( &projCellCounter,
                &totalCells,
                1, MPI_UNSIGNED_LONG, MPI_SUM, 0, MPI_COMM_WORLD);
	if(MPI_PROC_ID == 0){
		pout << "totalCells: " << totalCells << "totalArea (micron^2): " << grid.getCellArea()*totalCells;
		microStruct.writeInSTL();
	}
	grid.printPlaneInTecplot(MPI_PROC_ID, "Rotxy");

	pout.close();
	ierr = MPI_Finalize();
	return 0;
}
