#ifndef __ALGORITHM_HPP__
#define __ALGORITHM_HPP__

/*Created by Saurabh Sawant. 
 * Email: sssawant@illinois.edu
 * Date: 09/07/2018 
 */

#include "common.hpp"
#include "geometry.hpp"
#include <math.h>       /* for fabs */

template<typename T>
void SubVec(const dim<T>& a, const dim<T>& b, dim<T>& c)
{
	for (auto i=0; i<a.x.size(); i++)	
		c.x[i] = a.x[i] - b.x[i];
}


template<typename T, typename size_type>
char SegPlaneIntWithNormal(const dim<T>& f_a, const dim<T>& f_b, const dim<T>& f_c, const dim<T>& N, const dim<T>& q, const dim<T>& r, dim<T>& p, size_type* m){
	T D;

	dim<T> rq;
	long double num, denom,t;
	long double eps = 1E-14;
	size_type perfect_intersection = 1;
	D =  Dot(f_a, N);

	num = static_cast<long double>(D- Dot(q,N));
	SubVec(r,q,rq);
	denom = static_cast<long double>(Dot(rq,N));
	if (fabs(denom - 0.0)<eps){
		if (fabs(num - 0.0)<eps)
			return 'p';
		else
			return '0';
	}
	else
		t = num/denom;


	for(int i=0; i<3; i++) {
		p.x[i] = q.x[i] + t*(static_cast<long double>(r.x[i] - q.x[i]));
	}

	if(((fabs(p.x[0] - q.x[0])<eps) && (fabs(p.x[1] - q.x[1])<eps) && (fabs(p.x[2] - q.x[2])<eps)) ||
	((fabs(p.x[0] - r.x[0])<eps) && (fabs(p.x[1] - r.x[1])<eps) && (fabs(p.x[2] - r.x[2])<eps))) {
		perfect_intersection = 0;
//		std::cout << "perfect intersection not possible\n";
	 }

	if((0.0<(t+eps)) && (t<(1.0+eps)) && perfect_intersection == 1)
		return '1';
	else if (fabs(num - 0.0)<eps)
		return 'q';
	else if (fabs(num - denom)<eps)
		return 'r';
	else return '0';

	std::cout <<  "\'p\': seg lies wholly within plane.\n";
	std::cout <<  "\'q\': The first(q) endpoint is on the plane (but not \'p\').\n";
	std::cout <<  "\'r\': The (second) r endpoint is on the plane (but not \'p\').\n";
	std::cout <<  "\'0\': The segment lies strictly (line is parallel) to one side or the other of the plane.\n";
	std::cout <<  "\'1\': The segment intersects the plane, and none of {p,q,r} hold.\n";
}


template<typename T>
void NormalVec(const dim<T>& a, const dim<T>& b, const dim<T>& c, dim<T>& N)
{
	N.x[0] = (c.x[2] - a.x[2]) * (b.x[1] - a.x[1]) -
	         (b.x[2] - a.x[2]) * (c.x[1] - a.x[1]);
	N.x[1] = (b.x[2] - a.x[2]) * (c.x[0] - a.x[0]) -
	         (b.x[0] - a.x[0]) * (c.x[2] - a.x[2]);
	N.x[2] = (b.x[0] - a.x[0]) * (c.x[1] - a.x[1]) -
	         (b.x[1] - a.x[1]) * (c.x[0] - a.x[0]);

	T N_mag = pow((pow(N.x[0],2)+pow(N.x[1],2)+pow(N.x[2],2)),0.5);

	N.x[0] = N.x[0]/N_mag;
	N.x[1] = N.x[1]/N_mag;
	N.x[2] = N.x[2]/N_mag;
}

template<typename T>
T Dot(const dim<T>& a, const dim<T>& b)
{
	T sum = T(0);
    for (auto i = 0; i < a.x.size(); ++i) {
		sum += a.x[i]*b.x[i];
    }
	return sum;
}


template<typename T>
bool LeftOn(const dim<T>& a, const dim<T>& b, const dim<T>& c, const dim<T>& N) {
	dim<T> N1;
	T dotprod;

	NormalVec(a,b,c,N1);
	dotprod = Dot(N1,N);
	return dotprod >= 0;
}

template<typename T>
bool Point_In_Triangle(const dim<T>& intersection_pt_pos, const dim<T>& t0, const dim<T>& t1, const dim<T>& t2, const dim<T>& N) {
	if(
		LeftOn(intersection_pt_pos, t0, t1,N) &&
		LeftOn(intersection_pt_pos, t1, t2,N) &&
		LeftOn(intersection_pt_pos, t2, t0,N))
		return true;
	else
		return false;
}


template<typename ElemType, typename T>
bool checkPointInsideOrOutsideTheGeometry(const dim<T>& b, const dim<T>& a, geometry<ElemType,T>& microStruct) {

    using size_type = typename geometry<ElemType,T>::size_type;

	size_type intersectionCounter=0;
	char p = '?';
	size_type m;
	dim<T> ip;
	bool returnValue = false;
    for(size_type i=0; i<microStruct.glo_num_primitives; ++i) {
		dim<T>* vert1 = microStruct.prim[i].vert1;
		dim<T>* vert2 = microStruct.prim[i].vert2;
		dim<T>* vert3 = microStruct.prim[i].vert3;
		dim<T>* norm = microStruct.prim[i].norm;
    	size_type startPanID=0;
    	for(size_type i_sub=0; i_sub<microStruct.glo_num_subparts[i]; i_sub++)
    	{
    	    for(size_type i_pan=startPanID; i_pan<(startPanID+microStruct.glo_panels_per_subpart[i][i_sub]);i_pan++){
				p = SegPlaneIntWithNormal(vert1[i_pan], vert2[i_pan], vert3[i_pan], norm[i_pan], a, b, ip, &m);
				if(p == '1') { //segment intersects the plane
					if(Point_In_Triangle(ip , vert1[i_pan], vert2[i_pan], vert3[i_pan], norm[i_pan])) {
						intersectionCounter++;
					}
				}
    	    }
    	startPanID += microStruct.glo_panels_per_subpart[i][i_sub];
    	}
    }

	if(intersectionCounter%size_type(2) != 0) {
		returnValue = true;
	}
	return returnValue;
}

template<typename ElemType, typename T>
bool checkPointProjectionIntersectionWithTheGeometry(const dim<T>& b, const dim<T>& planeN, geometry<ElemType,T>& microStruct) {

    using size_type = typename geometry<ElemType,T>::size_type;

	size_type intersectionCounter=0;
	char p = '?';
	size_type m;
	dim<T> ip;
	T s = 4*microStruct.getLengthScale();

   	dim<T> a;
	a = b+s*planeN;
	bool returnValue = false;
	  for(size_type i=0; i<microStruct.glo_num_primitives; ++i) {
	    dim<T>* vert1 = microStruct.prim[i].vert1;
	    dim<T>* vert2 = microStruct.prim[i].vert2;
	    dim<T>* vert3 = microStruct.prim[i].vert3;
	    dim<T>* norm = microStruct.prim[i].norm;
	    size_type startPanID=0;
	    for(size_type i_sub=0; i_sub<microStruct.glo_num_subparts[i]; i_sub++)
	    {
	        for(size_type i_pan=startPanID; i_pan<(startPanID+microStruct.glo_panels_per_subpart[i][i_sub]);i_pan++){
	            p = SegPlaneIntWithNormal(vert1[i_pan], vert2[i_pan], vert3[i_pan], norm[i_pan], a, b, ip, &m);
	            if(p == '1') { //segment intersects the plane
	                if(Point_In_Triangle(ip , vert1[i_pan], vert2[i_pan], vert3[i_pan], norm[i_pan])) {
						return true;
	                }
	            }
	        }
	    startPanID += microStruct.glo_panels_per_subpart[i][i_sub];
	    }
	  }
	return false;	
}


#endif
