#ifndef __IO_HPP__
#define __IO_HPP__
//#include "geometry.hpp"
#include "common.hpp"
#include <iostream>
#include <string> 
#include <sstream>
template<typename T>
std::vector<T> &split(const std::string &s, char delim, std::vector<T> &elems) {
    std::stringstream ss(s);
    std::string item;
    while (ss >> item) {
        elems.push_back(std::stod(item));
    }
    return elems;
}

std::vector<std::string> &split(const std::string &s, char delim, std::vector<std::string> &elems) {
    std::stringstream ss(s);
    std::string item;
    while (std::getline(ss, item, delim)) {
        elems.push_back(item);
    }
    return elems;
}

template<typename T>
std::vector<T> split(const std::string &s, char delim) {
    std::vector<T> elems;
    split(s, delim, elems);
    return elems;
}


std::string ProcessorPrintOutPath(int procID){
    using std::string;
	string fID = "../Output/ProcFiles/Processor_";
	string pID =static_cast<std::ostringstream*>( &(std::ostringstream() << procID) )->str();
	string fE = ".out";
	string path = fID+pID+fE;
	return path;
}

template<typename size_type>
void readAndDefineGeometry(std::string GeomDef, std::string*& geomDataStr, size_type& glo_num_primitives, size_type*& glo_num_subparts){


	std::string fID = "../Input/";
	std::string fEnd = ".dat";
	std::string ff = fID+GeomDef+fEnd;
	std::ifstream geom_input(ff.c_str());

	std::string *mystr =new std::string;
	std::getline(geom_input,*mystr);
	std::stringstream(*mystr) >> glo_num_primitives;
	std::cout << "Number of primitives: " << glo_num_primitives << "\n";
	glo_num_subparts = new size_type[glo_num_primitives];
	geomDataStr = new std::string[glo_num_primitives];

	for(size_type i=0; i<glo_num_primitives; ++i) {
		std::getline(geom_input,*mystr);
		std::stringstream(*mystr) >> geomDataStr[i];
		std::getline(geom_input,*mystr);
		std::stringstream(*mystr) >> glo_num_subparts[i];
		std::cout << "Subparts in primitive " << i << "named: " << geomDataStr[i] << " are: "  << glo_num_subparts[i] << "\n";
	}
}

template<typename size_type>
void assessSTLFileAndDetermineTotalPanels(std::string geomDataStr, size_type& glo_total_panels, size_type glo_num_primitives, size_type* glo_panels_per_primitive, 
size_type* glo_num_subparts, size_type** glo_panels_per_subpart){
	std::string fID = "../Input/";
	std::string fEnd = ".stl";
	std::string ff = fID+geomDataStr+fEnd;
	std::ifstream stl_file(ff.c_str());

	size_type numLines=0;
	while(stl_file.good()){
		std::string line;
		std::getline(stl_file, line);
		++numLines;
	}

	numLines = numLines-1;
	std::cout << "Total number of lines: "<< numLines<< "\n";
	stl_file.close();


	stl_file.open(ff.c_str());
	std::string strl("solid");
	size_type counter=0;
	size_type solidLine=0;
	size_type numSubpart=0;
	size_type i=0;
	bool flag=false;
	for(i=0; i<numLines; i++) {
	        std::string line;
	        std::getline(stl_file, line);
	
	        if(line.length() < 50) {
	        	std::vector<std::string> x = split<std::string>(line, ' ');
	        	if(strl.compare(x[0])==0){
//	        		std::cout << "Geometry is a new solid with the name: " << x[1] << " at line: " << i<<  "\n";
	        		if(flag == true){
	        			glo_panels_per_subpart[0][numSubpart-1] = (i-solidLine-2)/7.0;
	        		}
//	        		std::cout << "Triangles in the primitive 0, subpart: " << numSubpart << "  "<< (i-solidLine-2)/7.0<< "\n";
	        		numSubpart++;
	        		solidLine=i;
	        		flag = true;
	        	}
	        }
	}
	std::cout << "Triangles in the primitive 0, subpart: " << numSubpart << "  " <<  (i-solidLine-2)/7.0 << "\n";
	std::cout << "numSubpart: " << numSubpart << "\n";
	glo_panels_per_subpart[0][numSubpart-1] = (i-solidLine-2)/7.0;
	
	glo_panels_per_primitive[0]=0;
	for(int i = 0;i<glo_num_subparts[0];i++)   {
		 glo_panels_per_primitive[0] += glo_panels_per_subpart[0][i];
	}
	std::cout << "#Total panels in the primitive 0: " <<  glo_panels_per_primitive[0] << "\n";
	stl_file.close();
	
	glo_total_panels =0;
	for(int i = 0;i<glo_num_primitives;i++)   {
	 glo_total_panels +=  glo_panels_per_primitive[i];
	}
	std::cout << "#Total panels in the entire geometry: " <<  glo_total_panels  << "\n";
}

#endif
