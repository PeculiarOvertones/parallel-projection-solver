#ifndef __PLANE_HPP__
#define __PLANE_HPP__
/*Created by Saurabh Sawant. 
 * Email: sssawant@illinois.edu
 * Date: 09/07/2018 
 */
#include <algorithm>
#include <iomanip>
#include <complex>
#include "common.hpp"
#include "rotationMatrix.hpp"
#include "ops.hpp"
#include <iostream>
#include <string>
#include <sstream>
#include "geometry.hpp"
#include "algorithm.hpp"

template<typename Celltype, typename T>
class plane {
public:
	typedef typename matrix<T>::size_type size_type;

    plane(size_type P, size_type PPD, size_type M, size_type N, T zetaL, T etaL, char D, int* sig)
    	:
		procPerDir(PPD), 
		vecData(M * N), 
		zeta(M),
		eta(N),
		zetaLength(zetaL),
		etaLength(etaL),
		Direction(D)
    {
		procID_ZetaCoord = P%procPerDir;
		procID_EtaCoord = (P-procID_ZetaCoord)/procPerDir;
		pout << "procID: " << P << "\n";
		pout << "procPerDir: " << procPerDir << "\n";
		pout << "procID_ZetaCoord: " << procID_ZetaCoord << "\n";
		pout << "procID_EtaCoord: " << procID_EtaCoord << "\n";
		for(size_type i=0; i<3; ++i){
			sign[i] = sig[i];
		}		
		dzB2.fill(T(0));
		deB2.fill(T(0));
		switch(Direction){
			case 'X':
				dzB2[1] = (zetaLength)/T(zeta)/T(2);
				deB2[2] = (etaLength)/T(eta)/T(2);
				planeNormal = {T(sign[0]),T(0),T(0)};
				pout << "Defined planeNormal: " << planeNormal << "\n";
				break;
			case 'Y':
				dzB2[2] = (zetaLength)/T(zeta)/T(2);
				deB2[1] = (etaLength)/T(eta)/T(2);
				planeNormal = {T(0), T(sign[0]),T(0)};
				break;
			case 'Z':
				dzB2[0] = (zetaLength)/T(zeta)/T(2);
				deB2[1] = (etaLength)/T(eta)/T(2);
				planeNormal = {T(0), T(0), T(sign[0])};
				break;
		}
		this->initializeQuadCellNodes();
    }

    plane(const plane& other)
    : vecData(other.vecData), 
      zeta(other.zeta),
      eta(other.eta)
    {

    }


    plane& operator=(const plane& other)
    {
        vecData = other.vecData;
        zeta = other.zeta;
        eta = other.eta;

        return *this;
    }

    Celltype& operator()(size_type z, size_type e)
    {
        return vecData[e * zeta + z];
    }
    
    const Celltype& operator()(size_type z, size_type e) const
    {
        return vecData[e * zeta + z];
    }


    size_type zetaCellCount() const
    {
        return zeta;
    }

    size_type etaCellCount() const
    {
        return eta;
    }

    T getCellArea() 
    {
		return zetaLength*etaLength/(T(zeta)*T(eta));
    }


	template<std::size_t SIZE>
	void rotatePlane(rotationMatrix<T>&, const std::array<char, SIZE>);
	void printPlaneInTecplot(size_type, std::string);
	template<typename ElemType>
	size_type tagCutAndInnerCells(geometry<ElemType,T>& microStruct);
private:
    container<Celltype> vecData;
    size_type procID_ZetaCoord;
    size_type procID_EtaCoord;
    size_type procPerDir;
    size_type zeta;
    size_type eta;
	dim<T> planeNormal;
	T zetaLength;
	T etaLength;
	std::array<T,3> dzB2;
	std::array<T,3> deB2;
	std::array<int,3> sign;
	char Direction;
    void initializeQuadCellNodes();
	T translateBasedOnProcID(T pos, const char locDir) {
	
		T returnPos;	
		switch(locDir) {
			case 'z':
				returnPos = pos - zetaLength*((T(procPerDir) - T(1))/T(2) - procID_ZetaCoord);
				break;
			case 'e':
				returnPos = pos - etaLength*((T(procPerDir) - T(1))/T(2) - procID_EtaCoord);
				break;
		}
		return returnPos;
	}
};

template<typename Celltype, typename T>
void plane<Celltype, T>:: initializeQuadCellNodes() {


	for (size_type e=0; e<eta; e++){
		for (size_type z=0; z<zeta; z++){

			switch(Direction){
				case 'X':
					this->operator()(z,e).cenPos.x[0] = T(0);			
					this->operator()(z,e).cenPos.x[1] = translateBasedOnProcID(sign[1]*dzB2[1]*T(2) * ((zeta-T(1))/T(2) - T(z)), 'z');
					this->operator()(z,e).cenPos.x[2] = translateBasedOnProcID(sign[2]*deB2[2]*T(2) * ((eta-T(1))/T(2) - T(e)), 'e');
					break;
				case 'Y':
					this->operator()(z,e).cenPos.x[0] = translateBasedOnProcID(sign[0]*deB2[0]*T(2) * (eta/T(2) - T(e)), 'e');			
					this->operator()(z,e).cenPos.x[1] = T(0);
					this->operator()(z,e).cenPos.x[2] = translateBasedOnProcID(sign[2]*dzB2[2]*T(2) * (zeta/T(2) - T(z)), 'z');
					break;
				case 'Z':
					this->operator()(z,e).cenPos.x[0] = translateBasedOnProcID(sign[0]*dzB2[0]*T(2) * (zeta/T(2) - T(z)), 'z');			
					this->operator()(z,e).cenPos.x[1] = translateBasedOnProcID(sign[1]*deB2[1]*T(2) * (eta/T(2) - T(e)), 'e');
					this->operator()(z,e).cenPos.x[2] = T(0);
					break;
			}
		}
	}
	pout << "Cells are initialized.\n";
}

template<typename Celltype, typename T>
template<std::size_t SIZE>
void plane<Celltype, T>:: rotatePlane(rotationMatrix<T>& RotM, const std::array<char,SIZE> rot_op) {

	for(size_type i=0; i<rot_op.size(); i++){

		switch (rot_op[i]){
			case 'X':
				planeNormal = matVecMul(RotM.Rx, planeNormal);
				break;
			case 'Y':
				planeNormal = matVecMul(RotM.Ry, planeNormal);
				break;
			case 'Z':
				planeNormal = matVecMul(RotM.Rz, planeNormal);
				break;
		}
	}

//	std::cout << "After rotation, plane Normal: " << planeNormal.x[0] << "  " << planeNormal.x[1] << "  " << planeNormal.x[2] << "\n";
	std::cout << "After rotation, plane Normal: " << planeNormal << "\n";

	for (size_type e=0; e<eta; e++){
    	for (size_type z=0; z<zeta; z++){
			for(size_type i=0; i<rot_op.size(); i++){

				switch (rot_op[i]){
					case 'X':
						this->operator()(z,e).cenPos = matVecMul(RotM.Rx, this->operator()(z,e).cenPos);
						break;
					case 'Y':
						this->operator()(z,e).cenPos = matVecMul(RotM.Ry, this->operator()(z,e).cenPos);
						break;
					case 'Z':
						this->operator()(z,e).cenPos = matVecMul(RotM.Rz, this->operator()(z,e).cenPos);
						break;
				}
			}
		}
	}

    if(zetaCellCount() > T(1) && etaCellCount() > T(1)){
    	for (size_type i=0; i<dzB2.size(); i++){
			dzB2[i] = (this->operator()(1,0).cenPos.x[i] - this->operator()(0,0).cenPos.x[i])*T(0.5);
			deB2[i] = (this->operator()(0,1).cenPos.x[i] - this->operator()(0,0).cenPos.x[i])*T(0.5);
		}
	}else{
		pout << "Increase the number of zeta and eta cells.\n";
	}
}

template<typename Celltype, typename T>
void plane<Celltype, T>:: printPlaneInTecplot(size_type procID, std::string f0) {

    size_type cellNum = zetaCellCount()*etaCellCount();
    size_type nodePerCell = 4;
    size_type nodeNum = nodePerCell * cellNum;

    std::ofstream outmyfile;
    std::string f2 = static_cast<std::ostringstream*>( &(std::ostringstream() << procID) )->str();
    std::string f, f1, ff;
    std::string end = ".tec";
    f = "../Output/";
	f1 = "_Plane_";
    ff = f + f0 + f1 + f2 + end;
    outmyfile.open(ff.c_str());

    outmyfile << "title = \"SUGAR TECPLOT\"" << '\n';
    outmyfile << "variables = \"X\", \"Y\", \"Z\", \"ID\",\"InOutFlag\"" << '\n';
    outmyfile << " zone T = \"Mesh\", n=" << nodeNum << " ,e=" << cellNum << " ,DATAPACKING=BLOCK, ZONETYPE=FEQUADRILATERAL" << '\n';
    outmyfile << " VARLOCATION = ([4-5] = CELLCENTERED)" << '\n';
    outmyfile << '\n';

    for (size_type p=0; p<3; p++) {
        size_type counter = 0;
		for (size_type e=0; e<eta; e++){
    		for (size_type z=0; z<zeta; z++){
				T cenP = this->operator()(z,e).cenPos.x[p];
            	outmyfile << std::setw(15) << cenP + dzB2[p] + deB2[p]
						  << std::setw(15) << cenP - dzB2[p] + deB2[p]
						  << std::setw(15) << cenP - dzB2[p] - deB2[p]
						  << std::setw(15) << cenP + dzB2[p] - deB2[p];
            	counter++;
            	if(counter%5 == 0){
					outmyfile << "\n";
            	}
			}
        }
		outmyfile << "\n";
		outmyfile << "\n";
    }

    size_type counter = 0;
	for (size_type e=0; e<eta; e++){
	   	for (size_type z=0; z<zeta; z++){
            outmyfile << std::setw(15) <<  this->operator()(z,e).id;
            counter++;
            if(counter%5 == 0){
              outmyfile << "\n";
            }
		}
    }
	outmyfile << "\n";
	outmyfile << "\n";

    counter = 0;
	for (size_type e=0; e<eta; e++){
   		for (size_type z=0; z<zeta; z++){
            outmyfile << std::setw(15) << this->operator()(z,e).inOutFlag;
            counter++;
            if(counter%5 == 0){
              outmyfile << "\n";
            }
		}
    }
	outmyfile << "\n";
	outmyfile << "\n";

    size_type cells[cellNum][nodePerCell];

    size_type dumNodeCounterConn=0;
    for (size_type i=0;i<cellNum;i++){
        for (int j=0;j<nodePerCell;j++){
            cells[i][j]=dumNodeCounterConn;
            dumNodeCounterConn++;
        }
    }
	outmyfile << "\n";
    for (size_type i =0; i<cellNum; i++){
         outmyfile << cells[i][0]+1 << " ";
         outmyfile << cells[i][1]+1 << " ";
         outmyfile << cells[i][2]+1 << " ";
         outmyfile << cells[i][3]+1 << " \n";
    }

    if(procID == 0){
		std::cout << "Tecplot files are outputted for the Mesh.\n";
    }
    outmyfile.close();
}


template<typename Celltype, typename T>
template<typename ElemType>
typename plane<Celltype,T>::size_type plane<Celltype, T>::tagCutAndInnerCells(geometry<ElemType,T>& microStruct) {

	/*Loop over cells*/
	dim<T> outerPointPos(1000,1000,1000);
	size_type projCellCounter=0;
	for (size_type e=0; e<eta; e++){
   		for (size_type z=0; z<zeta; z++){
//			pout << "checking for (z,e): (" << z << "," << e << ")\n";	
			this->operator()(z,e).inOutFlag = checkPointInsideOrOutsideTheGeometry(this->operator()(z,e).cenPos,outerPointPos, microStruct);	
			if(!this->operator()(z,e).inOutFlag){
	            this->operator()(z,e).inOutFlag = checkPointProjectionIntersectionWithTheGeometry(this->operator()(z,e).cenPos, planeNormal, microStruct);
			}
			if(this-operator()(z,e).inOutFlag){
				projCellCounter++;
			}
		}
    }
	return projCellCounter;
}
#endif /* plane_hpp */
