#ifndef __GEOMETRY_HPP__
#define __GEOMETRY_HPP__

/*Created by Saurabh Sawant. 
 * Email: sssawant@illinois.edu
 * Date: 09/07/2018 
 */


#include "common.hpp"
#include <string>



template<typename ElemType, typename T>
class geometry
{
public:
    typedef unsigned long size_type;

    geometry(std::string GeomDef)
 	{
		std::cout<< "Defining from: "  << GeomDef << "\n";
		readAndDefineGeometry<size_type>(GeomDef, geomDataStr, glo_num_primitives, glo_num_subparts);

	    prim = new ElemType[glo_num_primitives]; /*move this in main*/
	    glo_panels_per_primitive = new size_type[glo_num_primitives];
	    glo_panels_per_subpart   = new size_type*[glo_num_primitives];
		subpartString = new std::string*[glo_num_primitives];

	    for(size_type i=0; i<glo_num_primitives; i++) {
		    glo_panels_per_subpart[i] = new size_type[glo_num_subparts[i]];
			subpartString[i] = new std::string[glo_num_subparts[i]];
	    }
	
	    for(size_type i=0; i<glo_num_primitives; i++) {
	      for(size_type j=0; j<glo_num_subparts[i]; j++) {
	         glo_panels_per_subpart[i][j] = 0;
	      }
	    }
		panelMinPos = {1e05,1e05,1e05};
		panelMaxPos = {-1,-1,-1};

		for(size_type i = 0;i<glo_num_primitives;i++)
		{
			assessSTLFileAndDetermineTotalPanels<size_type>(geomDataStr[i], glo_total_panels, glo_num_primitives, 
			glo_panels_per_primitive, glo_num_subparts, glo_panels_per_subpart);
		    std::cout << "#Total panels: " <<  glo_total_panels  << "\n";
			prim[i].vert1 = new dim<T>[glo_panels_per_primitive[i]];
			prim[i].vert2 = new dim<T>[glo_panels_per_primitive[i]];
			prim[i].vert3 = new dim<T>[glo_panels_per_primitive[i]];
			prim[i].norm  = new dim<T>[glo_panels_per_primitive[i]];
			prim[i].toAwayNormalFlag  = new bool[glo_panels_per_primitive[i]];
			prim[i].readInTheGeometry(geomDataStr[i], glo_num_subparts[i],glo_panels_per_subpart[i], subpartString[i], panelMinPos, panelMaxPos);
		}
    } 	      
	void writeInSTL();
	void centerAtOrigin();

	static bool abs_compare(T a, T b)
	{
	    return (std::fabs(a) < std::fabs(b));
	}

	T getLengthScale() {
	    dim<T> diff;
	    diff = panelMaxPos - panelMinPos;
	    return *(std::max_element(diff.x.begin(), diff.x.end(), abs_compare));
	}


	ElemType* prim;
	size_type glo_num_primitives;
	size_type* glo_num_subparts;
	size_type* glo_panels_per_primitive;
	size_type** glo_panels_per_subpart;
	std::string** subpartString;
	size_type glo_total_panels; /*panels in all primitives of microstructure*/
	std::string* geomDataStr;
private:
	dim<T> panelMinPos;
	dim<T> panelMaxPos;
	
//void writeInSTL(string filename,  size_type glo_num_subparts, size_type*&glo_panels_per_subpart, size_type*& primitiveSubpartRemove, string*& subpartStringPrim, double* bin_limit, double* bin_temp, size_type* Bin_Number, dim* SphereCenter, size_type i_prim);
//
};


template<typename ElemType, typename T>
void geometry<ElemType,T>::writeInSTL(){
    for(size_type i=0; i<glo_num_primitives; ++i) {
        std::string f = "centered" + geomDataStr[i];
        prim[i].writeInSTL(f, glo_num_subparts[i], glo_panels_per_subpart[i], subpartString[i]);
    }
}

template<typename ElemType, typename T>
void geometry<ElemType,T>::centerAtOrigin(){
	dim<T> diff;
	dim<T> mid_length;
	mid_length.x[0] = 0.0;
	mid_length.x[1] = 0.0;
	mid_length.x[2] = 0.0;
	std::cout << "midlength : " << mid_length.x[0] << " " << mid_length.x[1] << "  " << mid_length.x[2] << "\n";
	
	diff.x[0] = mid_length.x[0] - (panelMinPos.x[0] +  (panelMaxPos.x[0] - panelMinPos.x[0])/2.0 );
	diff.x[1] = mid_length.x[1] - (panelMinPos.x[1] +  (panelMaxPos.x[1] - panelMinPos.x[1])/2.0 );
	diff.x[2] = mid_length.x[2] - (panelMinPos.x[2] +  (panelMaxPos.x[2] - panelMinPos.x[2])/2.0 );

	for(size_type i=0; i<glo_num_primitives; ++i) {
	    prim[i].translate(glo_num_subparts[i], glo_panels_per_subpart[i], diff);
	}
}

template<typename T>
template<typename size_type>
void triPanel<T>::translate(size_type glo_num_subparts, size_type*&glo_panels_per_subpart, dim<T>& diff){
	std::cout << "Translation distance : " << diff.x[0] << " " << diff.x[1] << "  " << diff.x[2] << "\n";
	size_type startPanID=0;
	for(size_type i_sub=0; i_sub<glo_num_subparts; i_sub++)
	{
		for(size_type i_pan=startPanID; i_pan<(startPanID+glo_panels_per_subpart[i_sub]);i_pan++){
			vert1[i_pan].x[0] = (vert1[i_pan].x[0] +diff.x[0]); 
			vert2[i_pan].x[0] = (vert2[i_pan].x[0] +diff.x[0]); 
			vert3[i_pan].x[0] = (vert3[i_pan].x[0] +diff.x[0]); 
			
			vert1[i_pan].x[1] = (vert1[i_pan].x[1] +diff.x[1]); 
			vert2[i_pan].x[1] = (vert2[i_pan].x[1] +diff.x[1]); 
			vert3[i_pan].x[1] = (vert3[i_pan].x[1] +diff.x[1]); 
			
			vert1[i_pan].x[2] = (vert1[i_pan].x[2] +diff.x[2]); 
			vert2[i_pan].x[2] = (vert2[i_pan].x[2] +diff.x[2]); 
			vert3[i_pan].x[2] = (vert3[i_pan].x[2] +diff.x[2]); 
		}
	startPanID += glo_panels_per_subpart[i_sub];
	}
}

template<typename T>
template<typename size_type>
void triPanel<T>::readInTheGeometry(std::string geomDataStr,  size_type glo_num_subparts, size_type*&glo_panels_per_subpart, std::string*& subpartString,
	 dim<T>& panelMinPos, dim<T>& panelMaxPos){
    std::string fID = "../Input/";
    std::string fEnd = ".stl";
    std::string ff = fID+geomDataStr+fEnd;
    std::ifstream stl_file(ff.c_str());
	std::cout << "Reading data from: " << ff << "\n";
	size_type pan_id = 0;
	size_type startPanID = 0;
	size_type counter=0;
	for(size_type i_sub=0; i_sub<glo_num_subparts; i_sub++)
	{
		std::string *mystr = new std::string;
		getline(stl_file,*mystr); // SOLID_GEOM
		subpartString[i_sub] = *mystr;

		for(size_type i_pan=startPanID; i_pan<(startPanID+glo_panels_per_subpart[i_sub]);i_pan++)
		{
			char dummy1[8], dummy2[6];
			std::getline(stl_file,*mystr);
			
			std::stringstream ss_nor(*mystr);
			ss_nor >> dummy1 >> dummy2 >> norm[pan_id].x[0] >> norm[pan_id].x[1]
			                            >> norm[pan_id].x[2];
			std::getline(stl_file,*mystr); // outer loop
			
			std::getline(stl_file,*mystr); std::stringstream ss_v1(*mystr);
			ss_v1 >> dummy2 >> vert1[pan_id].x[0] >> vert1[pan_id].x[1] >> vert1[pan_id].x[2];
			
			std::getline(stl_file,*mystr); std::stringstream ss_v2(*mystr);
			ss_v2 >> dummy2 >> vert2[pan_id].x[0] >> vert2[pan_id].x[1] >> vert2[pan_id].x[2];
			
			std::getline(stl_file,*mystr); std::stringstream ss_v3(*mystr);
			ss_v3 >> dummy2 >> vert3[pan_id].x[0] >> vert3[pan_id].x[1] >> vert3[pan_id].x[2];

			for(int i_dim=0;i_dim<3;i_dim++)
			{
				if(vert1[pan_id].x[i_dim] < panelMinPos.x[i_dim])
				{
				  panelMinPos.x[i_dim] = vert1[pan_id].x[i_dim];
				}
				if(vert2[pan_id].x[i_dim] < panelMinPos.x[i_dim])
				{
				  panelMinPos.x[i_dim] = vert2[pan_id].x[i_dim];
				}
				if(vert3[pan_id].x[i_dim] < panelMinPos.x[i_dim])
				{
				  panelMinPos.x[i_dim] = vert3[pan_id].x[i_dim];
				}
				if(vert1[pan_id].x[i_dim] > panelMaxPos.x[i_dim])
				{
				  panelMaxPos.x[i_dim] = vert1[pan_id].x[i_dim];
				}
				if(vert2[pan_id].x[i_dim] > panelMaxPos.x[i_dim])
				{
				  panelMaxPos.x[i_dim] = vert2[pan_id].x[i_dim];
				}
				if(vert3[pan_id].x[i_dim] > panelMaxPos.x[i_dim])
				{
				  panelMaxPos.x[i_dim] = vert3[pan_id].x[i_dim];
				}
			}
			
			std::getline(stl_file,*mystr); // end loop
			std::getline(stl_file,*mystr); // end facet
			pan_id++ ;
		}
		std::getline(stl_file,*mystr); // end GEOM
		startPanID += glo_panels_per_subpart[i_sub];
		counter++;
	} //subpart
	stl_file.close();
}


template<typename T>
template<typename size_type>
void triPanel<T>::writeInSTL(std::string filename,  size_type glo_num_subparts, size_type*&glo_panels_per_subpart, std::string*& subpartString){
    std::string fID = "../Output/";
	std::string filenameSTL = fID+filename+".stl";
	std::ofstream stl_file(filenameSTL.c_str());
	std::cout << "Writing stl geometry to file: " << filenameSTL.c_str() << "\n";
	size_type startPanID = 0;
	for(size_type i_sub=0; i_sub<glo_num_subparts; i_sub++)
	{
		stl_file << subpartString[i_sub] << "\n";
		for(size_type i_pan=startPanID; i_pan<(startPanID+glo_panels_per_subpart[i_sub]);i_pan++)
		{
			stl_file << "  facet normal " << norm[i_pan].x[0] <<" "<< norm[i_pan].x[1] <<" "<< norm[i_pan].x[2] << "\n";
			stl_file << "    outer loop"<< "\n";
			stl_file << "     vertex "<< vert1[i_pan].x[0] <<" "<<vert1[i_pan].x[1] <<" "<< vert1[i_pan].x[2] << "\n";
			stl_file << "     vertex "<< vert2[i_pan].x[0] <<" "<<vert2[i_pan].x[1] <<" "<< vert2[i_pan].x[2] << "\n";
			stl_file << "     vertex "<< vert3[i_pan].x[0] <<" "<<vert3[i_pan].x[1] <<" "<< vert3[i_pan].x[2] << "\n";
			stl_file << "    endloop"<< "\n";
			stl_file << "  endfacet"<< "\n";
		}
		stl_file << "end"<<  subpartString[i_sub] << "\n";
		startPanID += glo_panels_per_subpart[i_sub];
	} //subpart
	stl_file.close();
}                                                                                          

#endif
