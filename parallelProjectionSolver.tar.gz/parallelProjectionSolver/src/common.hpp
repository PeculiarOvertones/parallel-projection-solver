#ifndef __COMMON_HPP__
#define __COMMON_HPP__
/*Created by Saurabh Sawant. 
 * Email: sssawant@illinois.edu
 * Date: 09/07/2018 
 */

#include <vector>
#include <array>
#include <algorithm>
#include <cmath>
// alias template for a container type
template<typename T>
using container = std::vector<T>;

std::ofstream pout;

template<typename T>
struct dim {
    std::array<T,3> x;
	dim() {
		x = {0, 0, 0};
	}

	dim(T a,T b,T c) {
		x = {a,b,c};
	}
	
	dim(dim<T>& v) {
		x = {v.x[0], v.x[1], v.x[2]};
	}

    dim& operator=(const std::initializer_list<T> lst)
    {
		if(lst.size() == x.size()){
			std::copy(lst.begin(), lst.end(), x.begin());
		}
        return *this;
    }

};
template<typename T>
dim<T> operator-(const dim<T>& v1, const dim<T>& v2)
{

    dim<T> result;
    for (auto i = 0; i < v1.x.size(); ++i)
    {
        result.x[i] = v1.x[i] - v2.x[i];
    }

    return result;
}

template<typename T>
dim<T> operator+(const dim<T>& v1, const dim<T>& v2)
{

    dim<T> result;
    for (auto i = 0; i < v1.x.size(); ++i)
    {
        result.x[i] = v1.x[i] + v2.x[i];
    }

    return result;
}

template<typename T>
dim<T> operator*(const T& scalar, const dim<T>& v)
{
    dim<T> result;
    for (auto i = 0; i < v.x.size(); ++i)
    {
        result.x[i] = v.x[i] * scalar;
    }

    return result;
}

template<typename T>
std::ostream& operator<<(std::ostream& stream, const dim<T>& v)
{   
    stream << "(";
    for (auto i = 0; i < v.x.size(); ++i)
    {   
        if (i != v.x.size() - 1) {
            stream << v.x[i] << "; ";
        } else {
            stream << v.x[i];
        }
    }
    stream << ")";
    return stream;
}



template<typename T>
struct quadCell {
public:
	int id;
	bool inOutFlag;
    dim<T> cenPos;
};

template<typename T>
struct triPanel {
public:
    dim<T> *vert1;
    dim<T> *vert2;
    dim<T> *vert3;
    dim<T> *norm;
    bool* toAwayNormalFlag;
template<typename size_type>
	void readInTheGeometry(std::string GeomData,  size_type glo_num_subparts, size_type*&glo_panels_per_subpart, 
	std::string*& subpartStringPrim, dim<T>& panelMinPos, dim<T>& panelMaxPos);
template<typename size_type>
	void writeInSTL(std::string filename,  size_type glo_num_subparts, size_type*&glo_panels_per_subpart, std::string*& subpartStringPrim);
template<typename size_type>
	void translate(size_type glo_num_subparts, size_type*&glo_panels_per_subpart, dim<T>& diff);
};

#endif 
