#ifndef __ROTATIONMATRIX_HPP__
#define __ROTATIONMATRIX_HPP__
/*Created by Saurabh Sawant. 
 * Email: sssawant@illinois.edu
 * Date: 09/07/2018 
 */

#include "matrix.hpp"
#include "nvector.hpp"
#include "ops.hpp"
#include "rotationMatrix.hpp"

template<typename T>
struct rotationMatrix {       
public:
	typedef typename matrix<T>::size_type size_type;


	rotationMatrix(size_type N, T alpha, T beta, T gamma)
	: Rx(N, N), Ry(N,N), Rz(N,N),A(alpha*M_PI/180), B(beta*M_PI/180), C(gamma*M_PI/180), size(N)
	{
		std::cout << "A: " << A << "\n";	
		switch(size) {
		case 3 :	
				container<nvector<T>> Rx_basis;
				Rx_basis.push_back(nvector<T>(size, {1, 0, 0}));
				Rx_basis.push_back(nvector<T>(size, {0, cos(A), sin(A)}));
				Rx_basis.push_back(nvector<T>(size, {0, -sin(A), cos(A)}));
				Rx = construct_from_column_vectors(Rx_basis);

				container<nvector<T>> Ry_basis;
				Ry_basis.push_back(nvector<T>(size, {cos(B), 0, -sin(B)}));
				Ry_basis.push_back(nvector<T>(size, {0, 1, 0}));
				Ry_basis.push_back(nvector<T>(size, {sin(B), 0, cos(B)}));
				Ry = construct_from_column_vectors(Ry_basis);

				container<nvector<T>> Rz_basis;
				Rz_basis.push_back(nvector<T>(size, {cos(C), sin(C), 0}));
				Rz_basis.push_back(nvector<T>(size, {-sin(C),cos(C), 0}));
				Rz_basis.push_back(nvector<T>(size, {0, 0, 1}));
				Rz = construct_from_column_vectors(Rz_basis);
				break;
		}	         
	}
	
matrix<T> Rx;
matrix<T> Ry;
matrix<T> Rz;

void updateTheta(T alpha, T beta, T gamma);
private:
T A; /*X rotation angle*/
T B; /*Y */
T C; /*Z */
size_type size;
};

template<typename T>
void rotationMatrix<T>:: updateTheta(T alpha, T beta, T gamma) {
		A = alpha*M_PI/180;	
		B =  beta*M_PI/180;	
		C = gamma*M_PI/180;	
		switch(size) {
		case 3 :
				container<nvector<T>> Rx_basis;
				Rx_basis.push_back(nvector<T>(size, {1, 0, 0}));
				Rx_basis.push_back(nvector<T>(size, {0, cos(A), sin(A)}));
				Rx_basis.push_back(nvector<T>(size, {0, -sin(A), cos(A)}));
				Rx = construct_from_column_vectors(Rx_basis);

				container<nvector<T>> Ry_basis;
				Ry_basis.push_back(nvector<T>(size, {cos(B), 0, -sin(B)}));
				Ry_basis.push_back(nvector<T>(size, {0, 1, 0}));
				Ry_basis.push_back(nvector<T>(size, {sin(B), 0, cos(B)}));
				Ry = construct_from_column_vectors(Ry_basis);

				container<nvector<T>> Rz_basis;
				Rz_basis.push_back(nvector<T>(size, {cos(C), sin(C), 0}));
				Rz_basis.push_back(nvector<T>(size, {-sin(C),cos(C), 0}));
				Rz_basis.push_back(nvector<T>(size, {0, 0, 1}));
				Rz = construct_from_column_vectors(Rz_basis);
				break;
		}	         
}
#endif
